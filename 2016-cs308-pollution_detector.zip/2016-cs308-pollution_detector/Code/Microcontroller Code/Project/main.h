/*
 * main.h
 *
 *  Created on: Aug 14, 2015
 *      Author: secakmak
 */

#ifndef MAIN_H_
#define MAIN_H_

extern void SetServoAngle(uint32_t angle);
extern QuitProcess(void);

#endif /* MAIN_H_ */
