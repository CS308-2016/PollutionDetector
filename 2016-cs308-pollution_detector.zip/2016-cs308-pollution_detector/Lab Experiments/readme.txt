Group A 

Arpit Singh(120050037)
Jayesh Bageriya(120050022)


Group B

Ayush Deothia(120050025)
Avinash Malviya(120050024) 


Group C
Zubin Arya(120050036)



Add a well documented and commented code of your experiments in the respective folders.
