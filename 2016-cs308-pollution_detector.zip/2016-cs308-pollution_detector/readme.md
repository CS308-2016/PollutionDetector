Project Name: Pollution Detector

Team Members:
1. Ayush Deothia (120050025) - Team Leader
2. Arpit Singh(120050037)
3. Jayesh Bageriya (120050022)
4. Zubin Arya (120050036)
5. Avinash Malviya (120050024) 

Project Description:
The project is to create a small carbon dioxide level detector which can be fit into vehicles, rooms or offices of factories which will alarm a buzzer if its level increases above a certain threshold. Plus, the readings are sent via wifi to a server (which can be there in the nearest service center).